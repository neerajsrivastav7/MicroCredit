package handler

import (
	"errors"
	"fmt"
	"microCreditplus/pkg/comman"
	"microCreditplus/pkg/database"
	"sync"
	"time"
)

type Losic struct {
	lc              database.Database
	toralCollection sync.RWMutex
	Collection      map[string]comman.TodayCollection
}

func (l *Losic) StartDailyCleanup() {
	// Start a goroutine to perform cleanup every day at 4 PM
	go func() {
		// Calculate the duration until next 4 PM
		now := time.Now()
		nextCleanup := time.Date(now.Year(), now.Month(), now.Day(), 16, 0, 0, 0, now.Location())
		if now.After(nextCleanup) {
			nextCleanup = nextCleanup.Add(24 * time.Hour)
		}
		durationUntilNextCleanup := nextCleanup.Sub(now)

		// Wait until next cleanup time
		time.Sleep(durationUntilNextCleanup)

		// Perform cleanup
		l.toralCollection.Lock()
		defer l.toralCollection.Unlock()
		l.Collection = make(map[string]comman.TodayCollection)
	}()
}

func (l *Losic) Start() {
	l.Collection = make(map[string]comman.TodayCollection)
	l.StartDailyCleanup()
}

func (l *Losic) AddInTotalCollection(value int, name string) {
	l.toralCollection.Lock()
	defer l.toralCollection.Unlock()

	if l.Collection == nil {
		l.Collection = make(map[string]comman.TodayCollection)
	}

	if existing, ok := l.Collection[name]; ok {
		existing.Money += value
		l.Collection[name] = existing
	} else {
		l.Collection[name] = comman.TodayCollection{
			Name:  name,
			Money: value,
		}
	}
}

func (l *Losic) AddUserLosicHandler(user comman.User) error {
	amoutDetail, userinfo, userDetail, err := comman.DitributeData(user)
	if err != nil {
		return err
	}
	infoError := l.lc.InsertUserInfo(userinfo)
	amountError := l.lc.InsertAmount(amoutDetail)
	detailError := l.lc.InsertDetails(userDetail)

	if infoError != nil {
		return infoError
	}
	if amountError != nil {
		return amountError
	}
	if detailError != nil {
		return detailError
	}
	return nil
}

func (l *Losic) deleteUserHandlerLosic(user comman.DeleteUser) error {
	// Check if SubName exists in the user struct
	if user.SubName == "" {
		return fmt.Errorf("SubName is required")
	}
	subName := user.SubName
	err := l.lc.DeleteUser(subName)
	if err != nil {
		return errors.New(err.Error())
	}
	return nil
}

func (l *Losic) AddMoneyLosicHandler(addMoney comman.AddMoney) error {
	day := addMoney.Day
	remainingAmount := day * (addMoney.PaidAmount)
	addMoneyError := l.lc.AddMoneyQuery(day, remainingAmount, addMoney.SubName)
	if addMoneyError != nil {
		return addMoneyError
	}
	go l.AddInTotalCollection(addMoney.PaidAmount, addMoney.SubName)
	return nil
}

func (l *Losic) GetAllUserLogisHandler() ([]comman.SettlementData, error) {
	users, err := l.lc.GetAllData()
	return users, err
}

func (l *Losic) GetAllUserLogisHandlerByName(name string) ([]comman.SubNameDetail, error) {
	users, err := l.lc.GetSubNameDetailByName(name)
	return users, err
}

func (l *Losic) TodayCollectionLosicHandler() (interface{}, error) {
	return l.Collection, nil
}

func (l *Losic) GetDetailHandler() (interface{}, error) {
	details, err := l.lc.GetDetailData()
	if len(details) == 0 {
		details = []comman.UserDetails{
			{
				Name:                 "Dummy",
				TotalGivenAmount:     10600,
				TotalDailyPaidAmount: 200,
				NextPaidDate:         "2024-05-30",
			},
		}
	}
	return details, err

}
func (l *Losic)AddMoneyByNameLosicHandler(addMoney comman.AddMoneyByName) error {
	userName := addMoney.UserName
	noofDays := addMoney.NoOfDays
	TotalPaidAmount := addMoney.TotalPaidAmount
	moneyType  := addMoney.MType
	var err error
	if moneyType == "name"{
		err = l.lc.AddMoneyByName(userName, noofDays, TotalPaidAmount)
	} else if moneyType == "subName" {
		err = l.lc.AddMoneyBySubName(userName, noofDays, TotalPaidAmount)
	} else {
		err = errors.New("type of Add money is not Valid")
	}
	return err
}

func (l *Losic)GetDetailLosicHandler(name string) (interface{},error){
	detail , err := l.lc.GetDetailByName(name)
	return detail, err
	
}

func (l *Losic)GetDetailLosicHandlerForSubName(subname string) (interface{}, error) {
	detail , err := l.lc.GetDetailBySubName(subname)
	fmt.Println(detail)
	return detail, err
}

func (l *Losic)DeleteUserHandlerLosic(subName string) (error) {
	err := l.lc.DeleteUserBySubName(subName)
	return err
}