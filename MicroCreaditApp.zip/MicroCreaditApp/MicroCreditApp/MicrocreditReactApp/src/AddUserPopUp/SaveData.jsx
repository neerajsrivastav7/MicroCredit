function SaveData(data) {
    console.log(FormData)
}

export default SaveData;