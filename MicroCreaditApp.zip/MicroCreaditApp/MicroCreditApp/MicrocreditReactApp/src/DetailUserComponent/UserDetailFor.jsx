import "./Heading.css"
function UserDetailFor({ UserName }) {
  return <h4 className = "heading" >Detail For {UserName}</h4>;
}

export default UserDetailFor;
