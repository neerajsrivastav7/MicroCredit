import { Fragment } from "react";
import Login from "../LoginComponent/Login/";
import Navbar from "../NavigatorComponent/Navigator";
function LoginPage() {
  return (
    <Fragment>
      <Navbar />
      <Login />
    </Fragment>
  );
}

export default LoginPage;

