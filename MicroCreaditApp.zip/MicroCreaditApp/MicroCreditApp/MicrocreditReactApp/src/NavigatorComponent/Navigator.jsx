import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDate = (date) => {
    const options = {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    };
    return date.toLocaleDateString(undefined, options);
  };

  const handleGoBack = () => {
    navigate(-1);
  };
  return (
    <nav className="navbar navbar-light bg-primary fixed-top">
      <div className="container">
        <button className="btn btn-outline-dark" onClick={handleGoBack}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <div className="navbar-brand mx-auto">
          {formatDate(currentDateTime)}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;




