import React, { Fragment } from "react";
import Navbar from "../NavigatorComponent/Navigator";
import CardDataComponent from "./CardDataComponent"
import MicroButton from "./button";
import FooterRoot from "../Footer/FooterRoot";
function CardDetail() {
  return <Fragment>
    <Navbar/>
    <MicroButton/>
    <CardDataComponent/>
    <FooterRoot/>
  </Fragment>
}

export default CardDetail;
