// ButtonFunctions.jsx
import React from 'react';

function addUser() {
    // Add your addUser functionality here
    alert("Add User functionality goes here.");
}

function viewCollection() {
    // Add your viewCollection functionality here
    alert("View Today's Collection functionality goes here.");
}


export { addUser, viewCollection};
