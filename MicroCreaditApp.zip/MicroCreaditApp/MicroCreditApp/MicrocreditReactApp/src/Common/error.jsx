function SetError(result){

}

export default SetError