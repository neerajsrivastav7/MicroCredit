function LoginHeader() {
  return <div class="card-header">Login</div>;
}

export default LoginHeader;
