function LoginButton() {
    return (
      // <button type="submit" class="btn btn-primary btn-block">
      <button type="submit"  className="btn btn-primary">
        Login
      </button>
    );
}

export default LoginButton